from kivy.app import App
from kivy.uix.boxlayout import BoxLayout

class ChoiceWindow(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

class ChoiceApp(App):
    def build(self):

        return ChoiceWindow()

if __name__=='__main__':
    ChoiceApp().run()